const Footer = () => {
    return ( 
        <footer>
            Copyright 2023 Ninja List
        </footer>
     );
}
 
export default Footer;