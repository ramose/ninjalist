const About = () => {
    return (  
        <div>
            <h1>About</h1>
            <p>Exercitation adipisicing et adipisicing dolor dolore est ullamco velit. Consectetur commodo eu minim nulla culpa labore. Est in anim dolore sit amet aliqua sunt dolor incididunt quis sint est fugiat nostrud. Eiusmod ipsum est nostrud amet velit nostrud.</p>
            <p>Exercitation adipisicing et adipisicing dolor dolore est ullamco velit. Consectetur commodo eu minim nulla culpa labore. Est in anim dolore sit amet aliqua sunt dolor incididunt quis sint est fugiat nostrud. Eiusmod ipsum est nostrud amet velit nostrud.</p>
        </div>
    );
}
 
export default About;